// Popup script for ChatGPT data clearing UI and tab management

// ── Tab switching functionality ──
document.querySelectorAll(".tab-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    const tabName = btn.getAttribute("data-tab");

    // Remove active class from all tabs and buttons
    document.querySelectorAll(".tab-content").forEach((tab) => {
      tab.classList.remove("active");
    });
    document.querySelectorAll(".tab-btn").forEach((button) => {
      button.classList.remove("active");
    });

    // Add active class to clicked tab and button
    document.getElementById(tabName).classList.add("active");
    btn.classList.add("active");
  });
});

// ── Clear data button functionality ──
document.getElementById("clearBtn").addEventListener("click", async () => {
  const btn = document.getElementById("clearBtn");
  const statusDiv = document.getElementById("status");

  // Disable button and show loading state
  btn.disabled = true;
  btn.textContent = "Clearing...";
  statusDiv.className = "status loading";
  statusDiv.textContent = "Processing...";

  // Send message to background script
  chrome.runtime.sendMessage({ action: "clearChatGPTData" }, (response) => {
    btn.disabled = false;
    btn.textContent = "Clear ChatGPT Data Now";

    if (response && response.success) {
      statusDiv.className = "status success";
      statusDiv.textContent = "✓ " + response.message;
    } else {
      statusDiv.className = "status error";
      statusDiv.textContent =
        "✗ " + (response?.message || "Failed to clear data");
    }
  });
});
