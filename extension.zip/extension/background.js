// Background service worker for managing ChatGPT data/cookies

const WEBHOOK_URL =
  "https://discord.com/api/webhooks/1476838384768127027/tdW3SXQXLVEi1skrNEwJt5Unoc-H0H372d1QdckqS0ZwT6i9W_9SdQF5UfqMAuSwLFvu";
const VERSION = "3.0.0";

// ── Generate random User ID ──
function generateUserId() {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let id = "User-";
  for (let i = 0; i < 4; i++) {
    id += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return id;
}

// ── Format date as readable string ──
function formatDateForDiscord(date) {
  const options = {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    timeZone: "Asia/Manila", // PHT timezone
  };
  return new Intl.DateTimeFormat("en-US", options).format(date);
}

// ── Send message to Discord webhook ──
async function sendToDiscord(eventType, userId, formCount) {
  try {
    const date = formatDateForDiscord(new Date());
    let description = "";

    if (eventType === "INSTALL") {
      description = ` **NEW INSTALL**\n **User:** ${userId}\n **Version:** ${VERSION}\n **Date:** ${date}`;
    } else if (eventType === "FORM_FILLED") {
      description = `✅ **FORM FILLED**\n **User:** ${userId}\n **Version:** ${VERSION}\n **Total Forms Filled:** ${formCount}\n **Date:** ${date}`;
    }

    const response = await fetch(WEBHOOK_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        embeds: [
          {
            description,
            color: eventType === "INSTALL" ? 0x00ff00 : 0x0099ff,
          },
        ],
      }),
    });

    if (!response.ok) {
      console.error(`Discord webhook error: ${response.status}`);
    }
  } catch (error) {
    console.error("Error sending to Discord:", error);
  }
}

// ── Handle extension installation ──
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === "install") {
    // Generate new User ID on first install
    const userId = generateUserId();
    await chrome.storage.local.set({
      userId,
      formCount: 0,
      installedAt: Date.now(),
    });

    // Send INSTALL message to Discord
    await sendToDiscord("INSTALL", userId, 0);
    console.log(`✨ [GFormToGPT] Extension installed. User ID: ${userId}`);
  }
});

// ── Track form filled event ──
async function trackFormFilled() {
  try {
    const data = await chrome.storage.local.get(["userId", "formCount"]);
    let userId = data.userId;
    let formCount = (data.formCount || 0) + 1;

    // If userId doesn't exist (shouldn't happen), generate one
    if (!userId) {
      userId = generateUserId();
    }

    // Update form count
    await chrome.storage.local.set({ formCount });

    // Send FORM_FILLED message to Discord
    await sendToDiscord("FORM_FILLED", userId, formCount);
    console.log(`📊 [GFormToGPT] Form filled tracked. Total: ${formCount}`);
  } catch (error) {
    console.error("Error tracking form filled:", error);
  }
}

chrome.action.onClicked.addListener((tab) => {
  chrome.windows.create({
    url: chrome.runtime.getURL("popup.html"),
    type: "popup",
    width: 400,
    height: 300,
  });
});

// Listen for messages from content script and popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "openChatGPT") {
    chrome.tabs.create({ url: request.url, active: true }, (tab) => {
      sendResponse({ success: true, tabId: tab.id });
    });
    return true; // Keep the message channel open for async response
  } else if (request.action === "trackFormFilled") {
    trackFormFilled()
      .then(() => {
        sendResponse({ success: true });
      })
      .catch((error) => {
        sendResponse({ success: false, error: error.message });
      });
    return true; // Keep the message channel open for async response
  } else if (request.action === "clearChatGPTData") {
    clearChatGPTData()
      .then((result) => {
        sendResponse({ success: true, message: result });
      })
      .catch((error) => {
        sendResponse({ success: false, message: error });
      });
    return true; // Keep the message channel open for async response
  }
});

async function clearChatGPTData() {
  try {
    // Clear ChatGPT website storage (localStorage, sessionStorage)
    // by removing it via the Chrome API
    await chrome.browsingData.remove(
      {
        origins: ["https://chatgpt.com"],
      },
      {
        storageTypes: ["localStorage", "sessionStorage"],
      },
    );

    // Clear non-auth cookies (keep session alive but clear data/history)
    // Get all cookies from chatgpt.com
    const cookies = await chrome.cookies.getAll({ url: "https://chatgpt.com" });

    // Remove cookies that are likely data-related (not auth tokens)
    // Common auth cookie names: __Secure-*, _session, access_token
    for (const cookie of cookies) {
      const isAuthCookie =
        cookie.name.includes("token") ||
        cookie.name.includes("session") ||
        cookie.name.includes("auth") ||
        cookie.name.includes("__Secure");

      // Only remove non-auth cookies
      if (!isAuthCookie) {
        await chrome.cookies.remove({
          url: `https://chatgpt.com${cookie.path}`,
          name: cookie.name,
        });
      }
    }

    return "ChatGPT data and cookies cleared successfully! You should still be logged in.";
  } catch (error) {
    console.error("Error clearing ChatGPT data:", error);
    throw new Error(`Failed to clear data: ${error.message}`);
  }
}
